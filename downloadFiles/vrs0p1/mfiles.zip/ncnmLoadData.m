function [y, X, yTest, XTest] = ncnmLoadData(dataset)

% NCNMLOADDATA Load a dataset.
%
% [y, X, yTest, XTest] = ncnmLoadData(dataset)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue May 25 18:27:26 2004
% NCNM toolbox version 0.1




switch dataset
  case 'threeFive'
   
   load usps_train
   X = ALL_DATA;
   y = ALL_T;
   load usps_test
   XTest = ALL_DATA;
   yTest = ALL_T;
   classTrue = 3;
   for i = [0 1 2 4 6 7 8 9];
     index = find(y == i);
     X(index, :) = [];
     y(index, :) = [];
     index = find(yTest == i);
     XTest(index, :) = [];
     yTest(index, :) = [];
   end
   y = (y == classTrue)*2 - 1;
   yTest = (yTest == classTrue)*2 - 1;
  case 'fourNine'
   
   load usps_train
   X = ALL_DATA;
   y = ALL_T;
   load usps_test
   XTest = ALL_DATA;
   yTest = ALL_T;
   classTrue = 4;
   for i = [0 1 2 3 5 6 7 8];
     index = find(y == i);
     X(index, :) = [];
     y(index, :) = [];
     index = find(yTest == i);
     XTest(index, :) = [];
     yTest(index, :) = [];
   end
   y = (y == classTrue)*2 - 1;
   yTest = (yTest == classTrue)*2 - 1;
 case 'thorsten'
  [y, X] = svmlread('../data/example2/train_transduction.dat');
  [yTest, XTest] = svmlread('../data/example2/test.dat');

end
