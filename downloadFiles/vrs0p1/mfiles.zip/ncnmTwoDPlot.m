function ncnmTwoDPlot(model, iter, X, y)

% NCNMTWODPLOT Make a 2-D plot of the null category noise model.
%
% ncnmTwoDPlot(model, iter, X, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue May 25 21:38:56 2004
% NCNM toolbox version 0.1



if nargin < 4
  X = model.X;
  y = model.y;
end
clf
markerSize = 10;
lineWidth = 2;
title(['Iteration ' num2str(i)])
pointsNeg = plot(X(find(y(:, 1)==-1), 1), ...
		 X(find(y(:, 1)==-1), 2), ...
		 'gx', 'erasemode', 'xor', ...
		 'markersize', markerSize+2, ...
		 'linewidth', lineWidth);
hold on
pointsPos = plot(X(find(y(:, 1)==1), 1), ...
		 X(find(y(:, 1)==1), 2), 'ro', ...
		 'erasemode', 'xor', ...
		 'markersize', markerSize, ...
		 'linewidth', lineWidth);

pointUn = plot(X(:, 1), ...
	       X(:, 2), 'm.', ...
	       'erasemode', 'xor', 'markersize', 8);
set(gca, 'fontname', 'times')
set(gca, 'fontsize', 20);

if length(model.I)>0
  switch model.noise.type 
   case 'cmpnd'
    bias = model.noise.comp{1}.bias;
   otherwise
    bias = model.noise.bias;
  end
  % It's probably learnt something.
  xlim = get(gca, 'xlim');
  ylim = get(gca, 'ylim');
  [CX, CY, CZ] = ivmMeshVals(model, xlim, ylim, 30);
  [void, clines] =contour(CX, CY, CZ, [-bias-.5 -bias+.5], 'b--');
  set(clines, 'linewidth', lineWidth)
  [void, clines] =contour(CX, CY, CZ, [-bias -bias], 'r-');
  set(clines, 'linewidth', lineWidth);
  
end
drawnow