function [params, names] = ncnmNoiseExtractParam(noise)

% NCNMNOISEEXTRACTPARAM Extract parameters from null category noise model.
%
% [params, names] = ncnmNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri May 21 06:38:32 2004
% NCNM toolbox version 0.1



params = [noise.bias noise.gamman noise.gammap];

if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
  names{noise.numProcess+1} = ['Gamma -'];
  names{noise.numProcess+2} = ['Gamma +'];
end