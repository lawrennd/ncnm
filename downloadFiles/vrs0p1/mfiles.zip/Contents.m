% NCNM toolbox
% Version 0.1 Friday, June 4, 2004 at 13:28:21
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.1 1.0 $
% 
% DEMPROBIT1 Test IVM code on a toy feature selection
% DEMTHREEFIVE Try the IVM & NCNM on 3 vs 5.
% DEMTHREEFIVERESULTS Plot results from the three vs five experiments.
% DEMUNLABELLED1 Test IVM code on a toy feature selection
% GENERATECRESCENTDATA Generate crescent data.
% LNCUMGAUSSSUM The log of the weighted sum of two cumulative Gaussians.
% NCNMLIKELIHOOD Likelihood of data under null category noise model.
% NCNMLOADDATA Load a dataset.
% NCNMLOGLIKELIHOOD Log-likelihood of data under null category noise model.
% NCNMNOISEDISPLAY Display  parameters from null category noise model.
% NCNMNOISEEXPANDPARAM Expand null category noise model's structure from param vector.
% NCNMNOISEEXTRACTPARAM Extract parameters from null category noise model.
% NCNMNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for null category noise model.
% NCNMNOISEGRADIENTPARAM Gradient of the null category noise model's parameters.
% NCNMNOISENUG Update nu and g parameters associated with null category noise model.
% NCNMNOISEOUT Ouput from null category noise model.
% NCNMNOISEPARAMINIT null category noise model's parameter initialisation.
% NCNMNOISESITES Site updates for null category model.
% NCNMTWODPLOT Make a 2-D plot of the null category noise model.
