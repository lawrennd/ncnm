function y = ncnmNoiseOut(noise, mu, varsigma)

% NCNMNOISEOUT Ouput from null category noise model.
%
% y = ncnmNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu May 13 04:37:43 2004
% NCNM toolbox version 0.1



D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end

y = zeros(size(mu));
index = find(mu +noise.width/2 < 0);
y(index) = -1;
index = find(mu + noise.width/2 >= 0 & mu - noise.width/2 < 0);
y(index) = NaN;
index = find(mu - noise.width/2 >= 0);
y(index) = 1;
