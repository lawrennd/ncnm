function [m, beta] = ncnmNoiseSites(noise, g, nu, mu, varSigma, y)

% NCNMNOISESITES Site updates for null category model.
%
% [m, beta] = ncnmNoiseSites(noise, g, nu, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue May 18 23:28:42 2004
% NCNM toolbox version 0.1



% The standard code.
beta = nu./(1-nu.*varSigma);
m = mu + g./nu;
