function noise = ncnmNoiseExpandParam(noise, params)

% NCNMNOISEEXPANDPARAM Expand null category noise model's structure from param vector.
%
% noise = ncnmNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri May 21 06:38:08 2004
% NCNM toolbox version 0.1




noise.bias = params(1:noise.numProcess);
noise.gamman = params(noise.numProcess+1);
noise.gammap = params(noise.numProcess+2);
