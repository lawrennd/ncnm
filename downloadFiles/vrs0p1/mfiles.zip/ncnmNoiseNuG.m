function [g, nu] = ncnmNoiseNuG(noise, mu, varSigma, y)

% NCNMNOISENUG Update nu and g parameters associated with null category noise model.
%
% [g, nu] = ncnmNoiseNuG(noise, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue May 25 06:40:19 2004
% NCNM toolbox version 0.1



[g, dlnZ_dvs] = feval([noise.type 'NoiseGradVals'], ...
		      noise, ...
		      mu, varSigma, ...
		      y);

nu = g.*g - 2*dlnZ_dvs;


for i = 1:size(mu, 2)
  index = find(nu(:, i)< eps);
  nu(index) = eps;
end
