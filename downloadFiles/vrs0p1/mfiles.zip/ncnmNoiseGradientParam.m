function g = ncnmNoiseGradientParam(noise, mu, varsigma, y)

% NCNMNOISEGRADIENTPARAM Gradient of the null category noise model's parameters.
%
% g = ncnmNoiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue May 25 06:34:59 2004
% NCNM toolbox version 0.1



D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
c = 1./sqrt(noise.sigma2 + varsigma);
gnoise.bias = zeros(1, D);
gnoise.gammap = 0;
gnoise.gamman = 0;
epsilon = eps;
for j = 1:D
  % Do negative category first.
  index = find(y(:, j)==-1);
  if ~isempty(index)
    mu(index, j) = mu(index, j)+noise.width/2;
    u = mu(index, j).*c(index, j);
    gnoise.bias(j) = gnoise.bias(j) - sum(c(index, j).*gradLogCumGaussian(-u));
    gnoise.gamman = gnoise.gamman - length(index)/(1-noise.gamman);
  end

  % Do missing data.
  index = find(isnan(y(:, j)));
  if ~isempty(index)
    mu(index, j) = mu(index, j) + noise.width/2;
    u = mu(index, j).*c(index, j);
    uprime = (mu(index, j) - noise.width).*c(index, j);
    lndenom = lnCumGaussSum(-u, uprime, noise.gamman, noise.gammap);
    lnNumer1 = log(noise.gamman) -.5*log(2*pi) -.5*(u.*u);
    lnNumer2 = log(noise.gammap) -.5*log(2*pi) -.5*(uprime.*uprime);
    B1 = exp(lnNumer1 - lndenom);
    B2 = exp(lnNumer2 - lndenom);
    gnoise.bias(j) = gnoise.bias(j) + sum(c(index, j).*(B2-B1));
    gnoise.gammap = gnoise.gammap + sum(exp(lnCumGaussian(uprime) -lndenom));
    gnoise.gamman = gnoise.gamman + sum(exp(lnCumGaussian(-u) - lndenom));
  end
  
  % Highest category
  index = find(y(:, j) == 1);
  if ~isempty(index)
    mu(index, j) = mu(index, j) - noise.width/2;
    mu(index, j) = mu(index, j).*c(index, j);
    addpart = sum(c(index, j).*gradLogCumGaussian(mu(index, j)));
    gnoise.bias(j) = gnoise.bias(j) + addpart;
    % 
    gnoise.gammap = gnoise.gammap - length(index)/(1-noise.gammap);
  end
end
g = [gnoise.bias gnoise.gamman(:)' gnoise.gammap(:)'];
%g = [gnoise.bias 0];
