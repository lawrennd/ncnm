function options = ncnmOptions;

% NCNMOPTIONS Set default options for NCNM.
%
%	Description:
%	options = ncnmOptions;
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	ncnmOptions.m version 0


options = ivmOptions;
