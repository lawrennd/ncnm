function [m, beta] = ncnmNoiseSites(noise, g, nu, mu, varSigma, y)

% NCNMNOISESITES Site updates for null category model.
%
%	Description:
%	[m, beta] = ncnmNoiseSites(noise, g, nu, mu, varSigma, y)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	ncnmNoiseSites.m version 1.2


% The standard code.
beta = nu./(1-nu.*varSigma);
m = mu + g./nu;
