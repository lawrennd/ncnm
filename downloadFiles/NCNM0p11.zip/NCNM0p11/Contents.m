% NCNM toolbox
% Version 0.11		Friday 21 Apr 2006 at 16:59
% Copyright (c) 2006 Neil D. Lawrence
% 
% NCNMNOISEPOINTPLOT Plot the data-points for null category noise model.
% DEMPROBIT1 Test IVM code on a toy crescent data.
% DEMTHREEFIVE Try the IVM & NCNM on 3 vs 5.
% DEMTHREEFIVERESULTS Plot results from the three vs five experiments.
% DEMUNLABELLED1 Test IVM code on a toy crescent data.
% GENERATECRESCENTDATA Generate crescent data.
% LNCUMGAUSSSUM The log of the weighted sum of two cumulative Gaussians.
% NCNMCONTOUR Special contour plot showing null category region.
% NCNMLIKELIHOOD Likelihood of data under null category noise model.
% NCNMLOADDATA Load a dataset.
% NCNMLOGLIKELIHOOD Log-likelihood of data under null category noise model.
% NCNMNOISE3DPLOT Draw a 3D or contour plot for the NCNM noise model.
% NCNMNOISEDISPLAY Display  parameters from null category noise model.
% NCNMNOISEEXPANDPARAM Expand null category noise model's structure from param vector.
% NCNMNOISEEXTRACTPARAM Extract parameters from null category noise model.
% NCNMNOISEGRADVALS Compute gradient with respect to inputs to noise model.
% NCNMNOISEGRADIENTPARAM Gradient of parameters for NCNM.
% NCNMNOISENUG Update nu and g parameters associated with null category noise model.
% NCNMNOISEOUT Ouput from null category noise model.
% NCNMNOISEPARAMINIT null category noise model's parameter initialisation.
% NCNMNOISESITES Site updates for null category model.
% NCNMOPTIONS Set default options for NCNM.
% NCNMTWODPLOT Make a 2-D plot of the null category noise model.
